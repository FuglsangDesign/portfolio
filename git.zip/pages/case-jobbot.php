<section class="case jobbot">
    <header>
        <article class="left">
            <h1>Innovative job agent <span>"Jobbot"</span> ensures your job search</h1>
            <p>Jobbot is an innovative, smart and automated (AI) job agent who, without further action on your part, seeks work for you several times a month.</p>
            <a href="#">Visit Jobbot</a>
        </article>
        <figure>
            <img src="assets/images/cases/jobbot_mockup.png" />
        </figure>
    </header>
    <article class="problem">
        <h2>Problem Statement</h2>
        <h3>" It should be easier applying to work applications "<h3>
        <p>My friend and I was talking one night about job applications, for his new job. We came to the conclusion, that its amazing how there isn't much help to find when it comes to applying for a job. As we are both developers, it didn't take long before we came up with the idea of "Jobbot". </p>
    </article>
    
    <article class="tools">
        <h2>Tools and development languages</h2>
        <ul>
            <li><img src="https://upload.wikimedia.org/wikipedia/commons/0/00/HTML5_logo_black.svg" /></li>
            <li><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/96/Sass_Logo_Color.svg/2000px-Sass_Logo_Color.svg.png" /></li>
            <li><img src="https://i2.wp.com/redstart.fr/wp-content/uploads/2016/03/js-logo.png?fit=500%2C500" /></li>
            <li><img src="https://www.wpfaster.org/wp-content/uploads/2013/06/jquery-logo.png" /></li>
            <li><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/2/27/PHP-logo.svg/711px-PHP-logo.svg.png" /></li>
        </ul>
    </article>

    <article class="designProcess">
        <h2>Design process</h2>
        <ul>
            <li>
                <span>1</span>
                <p>Stategize<p>
            </li>
            <li>
                <span>2</span>
                <p>Research<p>
            </li>
            <li>
                <span>3</span>
                <p>Wireframe & mockup<p>
            </li>
            <li>
                <span>4</span>
                <p>Development<p>
            </li>
        </ul>
    </article>

    <article class="designElements">
        <h2>UI Design</h2>
        <h3>Fonts</h3>
        <p>Catamaran<br></p>
    </article>
</section>