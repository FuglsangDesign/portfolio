<section class="blog">
  <header>
    <div class="blogheaderLeft">
    <span class="state">Newest</span>
    <h1>What is it about UX design<i>.</i></h1>
    <a href="#">Read blog post</a>
    <span class="date">27-10/2018</span>
    </div>
    <figure>
      <img src="assets/images/blog/whatisitaboutUX.png" />
    </figure>
  </header>

  <section class="blogMasory">
    <article>
      <figure>
        <img src="assets/images/blog/tipsforwebdesign.jpg" />
      </figure>

      <div class="blogThumbWrapper">
        <span class="category">Web design</span>
        <a href="#">
          <h2>5 SECRETS OF IMAGE-RICH WEBSITES</h2>
          <p>In the following sections, we’ll discuss in detail five things to keep in mind when designing smart, image-rich websites in the modern era.</p>
        </a>
        <span class="date">27-10/2018</span>
      </div>
    </article>

    <article>
      <figure>
        <img src="assets/images/blog/20bestportfoliodesign.jpg" />
      </figure>

      <div class="blogThumbWrapper">
        <span class="category">Web design</span>
        <a href="#">
          <h2>20 best portfolio designs.</h2>
          <p>What we do have is a general mix of calm and soothing minimalist sites punctuated by riotous color which might, if you’re not ready for it, hurt your eyes for a second. Enjoy.</p>
        </a>
        <span class="date">27-10/2018</span>
      </div>
    </article>

    <article>
      <figure>
        <img src="assets/images/blog/alternativedictionaryforwebdesign.jpg" />
      </figure>

      <div class="blogThumbWrapper">
        <span class="category">Web design</span>
        <a href="#">
          <h2>THE ALTERNATIVE DICTIONARY OF WEB DESIGN TERMS</h2>
          <p>So here it is: here’s what the Secret Web Design Illuminati doesn’t want you to know. Read this article, and you’ll be able to dab on the haters with your hip new slang. Isn’t that swell?</p>
        </a>
        <span class="date">27-10/2018</span>
      </div>
    </article>

    <article>
    </article>

    <article>
    </article>
  </section>
</section>
