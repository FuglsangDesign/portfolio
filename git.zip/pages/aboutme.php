<section class="aboutme">
  <header>
    <figure class="headerBackground">
      <img src="assets/images/aboutmeHeader.jpeg" />
    </figure>

    <article>
      <figure>
        <img src="assets/images/profile.jpg" />
      </figure>
      <h1>Jakob Fuglsang</h1>
      <h2>Web developer & Graphic designer</h2>

      <ul>
        <li><a href="#"><i class="icon ion-logo-dribbble"></i></a></li>
        <li><a href="#"><i class="icon ion-logo-codepen"></i></a></li>
        <li><a href="#"><i class="icon ion-logo-instagram"></i></a></li>
      </ul>
    </article>
  </header>

  <section class="aboutmeMasory">

    <article class="description">
      <h2>Description</h2>
      <p>
        My name is Jakob Fuglsang, im from Denmark. I work as a freelance Web designer and Graphic designer. I specializes in high quality proffesionel design.
      </p>

    </article>

    <article class="generalinfo">
      <h2>General info</h2>
      <ul>
        <li>
          <h3>Gender</h3>
          <p>Male</p>
        </li>

        <li>
          <h3>Birthday</h3>
          <p>September 21, 1999</p>
        </li>
      </ul>

    </article>


    <article class="contactinfo">
      <h2>Contact info</h2>
      <ul>
        <li><i class="icon ion-md-call"></i><a href="tlf:+4560493477">+45 60 49 34 77</a></li>
        <li><i class="icon ion-md-paper-plane"></i><a href="mailto:jakob@fuglsang.dk">Jakob@Fuglsang.design</a></li>
        <li><i class="icon ion-md-compass"></i><p>Margrethevej 5, hirtshals <br>9850 Hirtshals<br>Denmark</p></li>
      </ul>

    </article>

    <article class="skills">
      <h2>Skills</h2>
      <ul>
        <li class="html">
          <p>html</p>
          <div class="indicator"><span></span></div>
        </li>

        <li class="css">
          <p>css</p>
          <div class="indicator"><span></span></div>
        </li>

        <li class="javascript">
          <p>javascript</p>
          <div class="indicator"><span></span></div>
        </li>

        <li class="photoshop">
          <p>Photoshop</p>
          <div class="indicator"><span></span></div>
        </li>

        <li class="illustrator">
          <p>Illustrator</p>
          <div class="indicator"><span></span></div>
        </li>
      </ul>

    </article>

    <article class="mapcontainer">
      <div id="map"></div>
    </article>

    <article class="work">
      <h2>Work history</h2>
      <ul>
        <li>
          <h3>Cleaning assistant</h3>
          <span>2013 - now</span>
          <a href="http://www.tannishus.dk" target="_blank">Hotel Tannishus</a>
        </li>

        <li>
          <h3>Freelance Graphic designer & Web developer</h3>
          <span>2017 - now</span>
          <a href="http://www.fuglsang.design" target="_blank">Fuglsang.design</a>
        </li>

        <li>
          <h3>Graphic design & web development</h3>
          <span>2018 - now</span>
          <a href="http://www.chork.dk" target="_blank">Chork i/s</a>
        </li>

      </ul>
    </article>

    <article class="education">
      <h2>Education</h2>
      <ul>
        <li>
          <h3>Boarding school</h3>
          <span>2015 - 2016</span>
          <a href="http://www.oeu.dk" target="_blank">Østhimmerlands ungdomsskole</a>
        </li>

        <li>
          <h3>Graphic Design</h3>
          <span>2017 - 2018</span>
          <a href="http://www.techcollege.dk" target="_blank">Tech college Aalborg</a>
        </li>

        <li>
          <h3>Web developer</h3>
          <span>2018 - now</span>
          <a href="http://www.techcollege.dk" target="_blank">Tech college Aalborg</a>
        </li>
      </ul>
    </article>


    <article class="contactformular">
      <h2>Let's get in touch</h2>
      <form>
        <div>
          <label id="fullnameLabel" for="">Fullname</label>
          <input type="text" id="fullnameInput" class="input"/>
        </div>

        <div>
          <label id="emailLabel" for="">Email</label>
          <input type="email" id="emailInput" class="input"/>
        </div>

        <div>
          <label id="subjectLabel" for="">Subject</label>
          <input type="text" id="subjectInput" class="input"/>
        </div>

        <div>
          <label for="">Message</label>
          <textarea name="message"></textarea>
        </div>

        <button>Submit</button>
      </form>
    </article>


  </section>
