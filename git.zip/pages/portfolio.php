<section class="portfolio">
  <ul>
    <li>
      <figure>
        <img src="assets/images/cases/jobbot_mockup.png" />
      </figure>
      <h3>Web development - Front-end website</h3>
      <h2>Jobbot</h2>
      <p>Jobbot is an automated job applicator, its job is to create both the application and curriculum vitae from information given by the user, and send them to an employer.</p>
      <a href="?page=case-jobbot"><span>Read more</span></a>
    </li>

    

    
    <li>
      <figure>
        <img src="assets/images/cases/kraftensbekaempelse.png" />
      </figure>
      <h3>Graphic Design - Advertisement</h3>
      <h2>Kræftens bekæmpelse</h2>
      <p>electricity is a well known concept, not just for the youth but for every generation living today. By illustrating a smoke and a battery, its possible to effect every age, to reduce the amount of smoking. </p>
      <a href="?page=case-jobbot"><span>Read more</span></a>
    </li>

    

    <li>
      <figure>
        <img src="assets/images/cases/dashboard_mockup.png" />
      </figure>
      <h3>Web development - Front-end website</h3>
      <h2>School dashboard</h2>
      <p>We've developed a dashboard with the purpose of showing and directing students to the correct classroom, we pulled the 
         school schedule from an external source which we we're given.</p>
      <a href="?page=case-jobbot"><span>Read more</span></a>
    </li>

    

    <li>
      <figure>
        <img src="assets/images/cases/legologo.jpg" />
      </figure>
      <h3>Graphic Design - Logo</h3>
      <h2>Lego</h2>
      <p>i wanted to modernize the lego logo. I liked the idea of having a icon for the logo not just a logo based on text.</p>
      <a href="?page=case-jobbot"><span>Read more</span></a>
    </li>
    
    <li>
      <figure>
        <img src="assets/images/cases/songbook_mockup.png" />
      </figure>
      <h3>Web development - Front-end website</h3>
      <h2>SongBook</h2>
      <p>I'm  big fan of playing music, so i made library for all the songs that im playing. You can look up songs and see both the lyrics and the chords for each song.</p>
      <a href="?page=case-jobbot"><span>Read more</span></a>
    </li>

    <li>
      <figure>
        <img src="assets/images/cases/ghostbeatlogo.png" />
      </figure>
      <h3>Graphic Design - Logo</h3>
      <h2>Ghostbeats</h2>
      <p>Ghostbeats is a high quality music gear company. It was important for me to create an icon, so that it could be printet on everthing.</p>
      <a href="?page=case-jobbot"><span>Read more</span></a>
    </li>



  </ul>
</section>
