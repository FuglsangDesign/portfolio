
var input = document.querySelectorAll('.contactformular input');
var label = document.querySelectorAll('.contactformular label');
var textarea = document.querySelector('.contactformular textarea');
var formdiv = document.querySelectorAll('.contactformular div');


for (let item of input) {
  item.addEventListener('click', function() {
      if (item.value === '') {
        item.previousElementSibling.classList.add('labelActive');
        item.parentElement.classList.add('borderActive');

      } else {
        item.previousElementSibling.classList.add('labelActive');
        item.parentElement.classList.add('borderActive');
      }
  })

  item.onblur = function() {
    if (item.value === '') {
      item.previousElementSibling.classList.remove('labelActive');
      item.parentElement.classList.remove('borderActive');
    } else {
      item.previousElementSibling.classList.add('labelActive');
    }
  }
}

textarea.addEventListener('click', function() {
    if (textarea.value === '') {
      textarea.previousElementSibling.classList.add('labelActive');
      textarea.parentElement.classList.add('borderActive');

    } else {
      textarea.previousElementSibling.classList.add('labelActive');
      textarea.parentElement.classList.add('borderActive');
    }
})

textarea.onblur = function() {
  if (textarea.value === '') {
    textarea.previousElementSibling.classList.remove('labelActive');
    textarea.parentElement.classList.remove('borderActive');
  } else {
    textarea.previousElementSibling.classList.add('labelActive');
    textarea.parentElement.classList.add('borderActive');
  }
}
