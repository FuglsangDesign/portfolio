document.querySelector('.openMenu').onclick = function() {
  document.querySelector('.topnav').classList.toggle("menuCollapse");
  document.querySelector('.main').classList.toggle("mainExpanded");
  document.querySelector('.openMenu').classList.toggle("menuRotated");
  document.querySelector('.portfolio ul').classList.toggle("portfolioExpanded");
}
