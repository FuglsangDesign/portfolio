<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8" />
    <title>Fuglsang – Development & Design</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="stylesheet" href="assets/css/master.css" />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,700|Open+Sans:400,700" rel="stylesheet">
    <link href="https://unpkg.com/ionicons@4.4.6/dist/css/ionicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">
  </head>
  <body>
    <?php
      $page = $_GET['page'];
    ?>
    <nav class="topnav">
      <figure class="profileImage">
        <img src="assets/images/profile.jpg" />
      </figure>
      <ul class="mainMenu">
        <li><a href="?page=portfolio">Portfolio</a></li>
        <!-- <li><a href="?page=blog">Blog</a></li> -->
        <li><a href="?page=aboutme">About me</a></li>
      </ul>

      <ul class="sm">
        <li><a href="#"><i class="icon ion-logo-dribbble"></i></a></li>
        <li><a href="#"><i class="icon ion-logo-codepen"></i></a></li>
        <li><a href="#"><i class="icon ion-logo-instagram"></i></a></li>

      </ul>

      <figure class="openMenu">
        <img src="assets/images/arrow.svg"/>
      </figure>
    </nav>

    <main class="main">


      <?php
      if(isset($page) && $page != ""){
        if(file_exists("pages/".$page.".php")){
          include("pages/".$page.".php");
        }else{
          include("pages/error.php");
        }
      }else{
        include("pages/portfolio.php");
      }
      ?>
    </main>

  <script src="assets/js/nav.js"></script>
  <script src="assets/js/form.js"></script>
  <script src="assets/js/maps.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDv_3BO_PgtbYtGNQATat8bD5-pg0sDimU&callback=initMap"></script>

  </body>
</html>
